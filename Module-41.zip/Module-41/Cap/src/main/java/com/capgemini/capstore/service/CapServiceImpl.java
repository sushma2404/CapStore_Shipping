package com.capgemini.capstore.service;

import java.sql.Date;
import java.time.LocalDate;
import java.util.Optional;
import java.util.concurrent.TimeUnit;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.capstore.bean.Cap;
import com.capgemini.capstore.dao.Dao;

@Service
public class CapServiceImpl implements CapService {
	@Autowired
	Dao dao;
	Date dOfOrderd;
	String e;

	@Override
	public void addProduct(Cap b) {
		dao.save(b);
	}

	@Override
	public void setStatus(int id) {

		Optional<Cap> c = dao.findById(id);
		if (c.isPresent()) {
			Cap c1 = c.get();
			dOfOrderd = c1.getDateOfOrd();
			long noOfdays = c1.getNoOfDaysForDelivery();
			LocalDate d = java.time.LocalDate.now();
			Date d2 = Date.valueOf(d);
			long diff = d2.getTime() - dOfOrderd.getTime();
			long diffDays = TimeUnit.DAYS.convert(diff, TimeUnit.MILLISECONDS);
			System.out.println(diffDays);
			
			if (diffDays == 0) {
				e = "order placed";
			}
			if (diffDays < noOfdays) {
				if (diffDays == 1 || diffDays == 2) {
					e = "order dispatched";
				} else if (diffDays == 3 || diffDays == 4 || diffDays == 5) {
					e = "order shipped";
				} else if (diffDays == 6) {
					e = "out for delivery";
				}

			} else {
				e = "order delivered";
			}
			//c1.setNoOfDaysForDelivery(diffDays);
			c1.setStatus(e);
	
			dao.save(c1);
		}

	}
	@Override
	public Cap getStatus(int id) {
		Optional<Cap> c = dao.findById(id);
		Cap c1 = null;
		if (c.isPresent()) {
			setStatus(id);
			c1 = c.get();
			return c1;
		}
		return null;
	}

}
