package com.capgemini.capstore.service;

import com.capgemini.capstore.bean.Cap;

public interface CapService {
	public void addProduct(Cap b);

	public void setStatus(int product_id);

	public Cap getStatus(int product_id);
}
