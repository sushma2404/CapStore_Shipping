package com.capgemini.capstore.exception;

public class CapException extends Exception {
	public CapException() {
		super();
	}

	public CapException(String msg) {
		super(msg);
	}
}
